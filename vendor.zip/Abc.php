<?php 
	
	Class Abc{
		public function __construct(){
			echo "Its my abc class";
		}
	}
?>
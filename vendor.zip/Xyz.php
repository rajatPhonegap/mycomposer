<?php 
	
	Class Xyz{
		public function __construct(){
			echo "Its my xyz class";
		}
	}
?>